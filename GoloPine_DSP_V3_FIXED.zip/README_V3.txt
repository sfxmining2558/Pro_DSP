
GoloPine DSP 7CH v3.0

Build:
GitHub Actions -> Run workflow

Features base:
MAIN UI
7CH Fader
Bluetooth Connect button
BP1048P4 DSP architecture preparation

Next modules:
EQ 15 Band
Crossover
Delay
Mixer
Preset
DSP Protocol
