package com.okn.golopinedsp;

import java.util.Locale;

/** GoloPine OEM BLE transport facts recovered from the supplied APK/HCI capture. */
public final class OemProtocol {
    public static final String SERVICE = "0000AB00-0000-1000-8000-00805F9B34FB";
    public static final String TX = "0000AB01-0000-1000-8000-00805F9B34FB";
    public static final String RX = "0000AB02-0000-1000-8000-00805F9B34FB";
    public static final int TX_HANDLE_OBSERVED = 0x0006;
    private OemProtocol() {}
    public static String describe() {
        return String.format(Locale.US, "OEM BLE %s / TX %s / RX %s / observed handle 0x%04X", SERVICE, TX, RX, TX_HANDLE_OBSERVED);
    }
    public static boolean looksLikeGattWriteCommand(byte[] att) {
        return att != null && att.length >= 3 && (att[0] & 0xff) == 0x52 && ((att[1]&0xff) | ((att[2]&0xff)<<8)) == TX_HANDLE_OBSERVED;
    }
}
