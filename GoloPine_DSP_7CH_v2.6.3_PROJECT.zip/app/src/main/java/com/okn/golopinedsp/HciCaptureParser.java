package com.okn.golopinedsp;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.*;

/** Minimal Android btsnoop parser for BLE ATT writes. It never transmits anything. */
public final class HciCaptureParser {
    public static final class Write {
        public long timestampUs; public int packetIndex; public int attOpcode; public int handle; public byte[] data;
        Write(long t,int i,int o,int h,byte[] d){timestampUs=t;packetIndex=i;attOpcode=o;handle=h;data=d;}
    }
    private HciCaptureParser() {}
    public static List<Write> parse(InputStream in) throws IOException {
        DataInputStream d=new DataInputStream(new BufferedInputStream(in));
        byte[] hdr=new byte[16]; if(d.read(hdr)!=16) throw new IOException("Not a btsnoop file");
        if(!(hdr[0]=='b'&&hdr[1]=='t'&&hdr[2]=='s'&&hdr[3]=='n'&&hdr[4]=='o'&&hdr[5]=='o'&&hdr[6]=='p')) throw new IOException("Invalid btsnoop header");
        ArrayList<Write> out=new ArrayList<>(); int idx=0;
        while(true){
            byte[] rh=new byte[24]; int n=readSome(d,rh); if(n==0) break; if(n!=24) break;
            int orig=u32(rh,0), incl=u32(rh,4); long ts=u64(rh,16); if(orig<0||incl<0||incl>4_000_000) break;
            byte[] p=new byte[incl]; d.readFully(p); idx++;
            if(incl<9 || (p[0]&0xff)!=2) continue; // ACL
            int aclLen=u16(p,3); if(aclLen<4 || 5+aclLen>p.length) continue;
            int l2len=u16(p,5), cid=u16(p,7); if(cid!=4 || l2len<3 || 9>p.length) continue;
            int end=Math.min(p.length,9+l2len);
            byte[] att=Arrays.copyOfRange(p,9,end); if(att.length<3) continue;
            int op=att[0]&0xff;
            if(op!=0x12 && op!=0x52) continue;
            int handle=u16(att,1); byte[] data=Arrays.copyOfRange(att,3,att.length);
            out.add(new Write(ts,idx,op,handle,data));
        }
        return out;
    }
    static int readSome(DataInputStream d,byte[] b)throws IOException{int off=0;while(off<b.length){int n=d.read(b,off,b.length-off);if(n<0)break;off+=n;}return off;}
    static int u16(byte[] b,int o){return (b[o]&255)|((b[o+1]&255)<<8);}
    static int u32(byte[] b,int o){return (b[o]&255)<<24|(b[o+1]&255)<<16|(b[o+2]&255)<<8|(b[o+3]&255);}
    static long u64(byte[] b,int o){long x=0;for(int i=0;i<8;i++)x=(x<<8)|(b[o+i]&255L);return x;}
    public static String hex(byte[] b){StringBuilder s=new StringBuilder();for(byte x:b)s.append(String.format(Locale.US,"%02X",x&255));return s.toString();}
}
