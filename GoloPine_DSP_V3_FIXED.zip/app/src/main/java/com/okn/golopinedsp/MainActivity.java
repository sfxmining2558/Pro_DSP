
package com.okn.golopinedsp;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;

public class MainActivity extends Activity {

 LinearLayout root;

 String[] ch={
 "CH1 Front L","CH2 Front R","CH3 SUB",
 "CH4 Rear L","CH5 Rear R",
 "CH6 AUX L","CH7 AUX R"
 };

 @Override
 public void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().setFlags(1024,1024);
  mainUI();
 }

 void mainUI(){
  root=new LinearLayout(this);
  root.setOrientation(LinearLayout.VERTICAL);
  root.setBackgroundColor(Color.rgb(15,18,22));

  TextView head=new TextView(this);
  head.setText("Bluetooth Connected\nBP1048P4 7CH DSP\nFW 1.2.6");
  head.setTextColor(Color.WHITE);
  head.setTextSize(20);
  root.addView(head);

  Button con=new Button(this);
  con.setText("เชื่อมต่อ DSP");
  root.addView(con);

  TextView master=new TextView(this);
  master.setText("Master Volume  -12.5 dB");
  master.setTextColor(Color.WHITE);
  root.addView(master);

  LinearLayout row=new LinearLayout(this);

  for(String s:ch){
   LinearLayout box=new LinearLayout(this);
   box.setOrientation(LinearLayout.VERTICAL);

   TextView t=new TextView(this);
   t.setText(s);
   t.setTextColor(Color.WHITE);

   SeekBar f=new SeekBar(this);
   f.setRotation(-90);

   Button m=new Button(this);
   m.setText("Mute");

   box.addView(t);
   box.addView(f,new LinearLayout.LayoutParams(120,350));
   box.addView(m);

   row.addView(box);
  }

  root.addView(row);
  setContentView(root);
 }
}
