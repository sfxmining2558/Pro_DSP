package com.golopine.dsp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.Composable

class MainActivity: ComponentActivity(){
 override fun onCreate(b:Bundle?){
  super.onCreate(b)
  setContent{ DSPApp() }
 }
}

@Composable
fun DSPApp(){
 MaterialTheme {
  Surface {
   Text("GoloPine DSP 7CH\nBP1048P4 DSP Controller\nMAIN  EQ  CROSSOVER  DELAY  MIXER")
  }
 }
}
