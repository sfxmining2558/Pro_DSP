package com.okn.golopinedsp;

import java.util.*;

public final class DspProtocol {
    private DspProtocol() {}
    public static byte[] frame(int control, byte[] payload) {
        if (payload == null) payload = new byte[0];
        byte[] out = new byte[payload.length + 5];
        out[0]=(byte)0xA5; out[1]=(byte)0x5A; out[2]=(byte)control; out[3]=(byte)payload.length;
        System.arraycopy(payload,0,out,4,payload.length); out[out.length-1]=0x16; return out;
    }
    public static byte[] query(int control){ return frame(control,new byte[0]); }
    public static byte[] firmwareInfoRequest(){ return query(0x00); }
    public static byte[] systemControlQuery(){ return query(0x01); }
    public static byte[] adc0PgaQuery(){ return query(0x03); }
    public static byte[] adc0DigitalQuery(){ return query(0x04); }
    public static byte[] adc1PgaQuery(){ return query(0x06); }
    public static byte[] adc1DigitalQuery(){ return query(0x07); }
    public static byte[] adc1AgcQuery(){ return query(0x08); }
    public static byte[] dac0Query(){ return query(0x09); }
    public static byte[] dac1Query(){ return query(0x0A); }
    public static byte[] i2s0Query(){ return query(0x0B); }
    public static byte[] i2s1Query(){ return query(0x0C); }
    public static byte[] spdifQuery(){ return query(0x0D); }
    public static byte[] effectListQuery(){ return frame(0x80,new byte[]{0x01}); }
    public static byte[] effectQuery(int effect){ return query(0x80 + Math.max(0,Math.min(0x7B,effect))); }
    public static byte[] protocolTest(int i){ switch(i){ case 0:return firmwareInfoRequest(); case 1:return effectListQuery(); case 2:return query(0x01); case 3:return query(0x09); case 4:return query(0x0A); default:return firmwareInfoRequest(); } }
    public static String hex(byte[] b){ if(b==null)return ""; StringBuilder s=new StringBuilder(); for(byte x:b)s.append(String.format(Locale.US,"%02X ",x&255)); return s.toString().trim(); }
    public static int control(byte[] f){ return f!=null&&f.length>=3 ? f[2]&255 : -1; }
    public static List<byte[]> split(byte[] data){
        List<byte[]> out=new ArrayList<>(); if(data==null)return out;
        for(int i=0;i+5<=data.length;i++) if((data[i]&255)==0xA5&&(data[i+1]&255)==0x5A){
            int n=data[i+3]&255; int total=n+5;
            if(i+total<=data.length && (data[i+total-1]&255)==0x16){out.add(Arrays.copyOfRange(data,i,i+total)); i+=total-1;}
        }
        return out;
    }
}
