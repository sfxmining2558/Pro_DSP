package com.okn.prodsp;
import android.app.*;import android.os.*;import android.graphics.Color;import android.widget.*;
public class MainActivity extends Activity{
 public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackgroundColor(Color.DKGRAY); TextView t=new TextView(this);t.setText("Pro DSP V3\nBP1048P4 7CH DSP\nConnect DSP\nMaster Volume");t.setTextColor(Color.WHITE);t.setTextSize(22);l.addView(t); for(int i=1;i<=7;i++){TextView c=new TextView(this);c.setText("CH"+i);c.setTextColor(Color.WHITE);l.addView(c,new LinearLayout.LayoutParams(-1,80));} setContentView(l);}
}